// JavaScript Document


    function initializeGoogleMap() {
		// set latitude and longitude to center the map around
		var latlng = new google.maps.LatLng(42.99561, -81.25285);
		
		// set up the default options
		var myOptions = {
		  zoom: 12,
		  center: latlng,
		  navigationControl: true,
		  navigationControlOptions: 
		  	{style: google.maps.NavigationControlStyle.DEFAULT,
			 position: google.maps.ControlPosition.TOP_LEFT },
		  mapTypeControl: true,
		  mapTypeControlOptions: 
		  	{style: google.maps.MapTypeControlStyle.DEFAULT,
			 position: google.maps.ControlPosition.TOP_RIGHT },

		  scaleControl: true,
		   scaleControlOptions: {
        		position: google.maps.ControlPosition.BOTTOM_LEFT
    	  }, 
		  mapTypeId: google.maps.MapTypeId.ROADMAP,
		  draggable: true,
		  disableDoubleClickZoom: false,
		  keyboardShortcuts: true
		};
		var map = new google.maps.Map(document.getElementById("mapCanvas"), myOptions);
		if (false) {
			var trafficLayer = new google.maps.TrafficLayer();
			trafficLayer.setMap(map);
		}
		if (false) {
			var bikeLayer = new google.maps.BicyclingLayer();
			bikeLayer.setMap(map);
		}
		if (false) {
			addMarker(map,42.99561,-81.25,"We are here");
		}
	  }

	  

	 // Add a marker to the map at specified latitude and longitude with tooltip
	 function addMarker(map,lat,long,titleText) {
	  	var markerLatlng = new google.maps.LatLng(lat,long);
	 	var marker = new google.maps.Marker({
      		position: markerLatlng, 
      		map: map, 
      		title:"We are here",
			icon: ""});   
	 }


window.onload = initializeGoogleMap();

/*THISSSSS IS THEEE STARTT OF TWITTTTERRRR WIDGETTTT!!!!!*/




$(document).ready(function() {
	$('#twitter_2').twitterSearch({
		term: 'Warschaff',
		title: 'Warschaff Gaming',
		titleLink: 'http://www.adobe.com/dreamweaver',
		bird: false ,					// true or false (show or hide twitter bird image)
		birdSrc: '/images/tweet.gif', 		// twitter bird image
		birdLink: 'https://twitter.com/WarSchaffGaming',		// url that twitter bird image should like to
		avatar: true,				// true or false (show or hide twitter profile images)
		anchors: true,			// true or false (enable embedded links in tweets)
		animOutSpeed: 500,	// speed of animation for top tweet when removed
		animInSpeed: 500,	// speed of scroll animation for moving tweets up
		pause: true,				// true or false (pause on hover)
		time: true,					// true or false (show or hide the time that the tweet was sent)
		timeout: 4000,			// delay betweet tweet scroll
		css: { 
			a:     { textDecoration: 'none', color: '#ffffff', fontWeight: 'normal'},
			container: { backgroundColor: '#999999' },
			frame: { border: '10px solid #cccccc', borderRadius: '10px', '-moz-border-radius': '10px', '-webkit-border-radius': '10px' },
			img:   { width: '30px', height: '30px' },
			loading: { color: '#888888' },
			text:  {fontWeight: 'normal', fontSize: '12px', color:'#000'},
			time:  { fontSize: '12px', color: '#0033ff' },
			title: { backgroundColor: '#666666', padding: '5px 0 5px 0', textAlign: 'center', fontWeight: 'bold', fontSize: '14px'},
			titleLink: { textDecoration: 'none', color: '#ffffff' },
			user:  { fontSize: '12px'},
			fail:  { background: '#6cc5c3 url(/images/failwhale.png) no-repeat 50% 50%'}
		}
	});
});
